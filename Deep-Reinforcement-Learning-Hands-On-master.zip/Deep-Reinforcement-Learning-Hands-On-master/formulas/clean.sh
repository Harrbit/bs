#!/bin/bash
rm *.pdf *.aux *.log
